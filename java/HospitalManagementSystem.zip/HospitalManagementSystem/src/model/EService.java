
package model;

/**
 *
 * @author jeremie
 */
public enum EService {
    CHECK_UP,SURGERY
}
