
package model;

/**
 *
 * @author jeremie
 */
public enum EAppointmentStatus {
    PENDING,COMPLETED,MISSED,REJECTED
}
