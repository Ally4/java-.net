
package model;

/**
 *
 * @author jeremie
 */
public enum EVisit {
    OPD,IPD
}
